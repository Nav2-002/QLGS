import React, { useState } from 'react';

const StoreManagement = () => {
  const [stores, setStores] = useState([]);
  const [form, setForm] = useState({
    storeId: '',
    name: '',
    phone: '',
    address: '',
    status: '',
  });
  const [editingIndex, setEditingIndex] = useState(null);

  const handleChange = (field, e) => {
    setForm({ ...form, [field]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.storeId || !form.name) return;

    const updated = [...stores];
    if (editingIndex !== null) {
      updated[editingIndex] = form;
      setEditingIndex(null);
    } else {
      updated.push(form);
    }

    setStores(updated);
    setForm({
      storeId: '',
      name: '',
      phone: '',
      address: '',
      status: '',
    });
  };

  const handleEdit = (index) => {
    setForm(stores[index]);
    setEditingIndex(index);
  };

  const handleDelete = (index) => {
    if (window.confirm('Bạn có chắc muốn xóa cửa hàng này không?')) {
      const updated = [...stores];
      updated.splice(index, 1);
      setStores(updated);
    }
  };

  const fieldLabels = {
    storeId: 'ID Cửa hàng',
    name: 'Tên cửa hàng',
    phone: 'SĐT',
    address: 'Địa chỉ',
    status: 'Trạng thái',
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.title}>Quản lý cửa hàng 🏬</h2>

      <form onSubmit={handleSubmit} style={styles.form}>
        {Object.entries(form).map(([key, value]) =>
          key === 'status' ? (
            <select
              key={key}
              value={value}
              onChange={(e) => handleChange(key, e)}
              style={styles.input}
            >
              <option value="">-- Trạng thái --</option>
              <option value="hoatdong">Hoạt động</option>
              <option value="dung">Dừng hoạt động</option>
            </select>
          ) : (
            <input
              key={key}
              type={key === 'phone' ? 'tel' : 'text'}
              placeholder={fieldLabels[key]}
              value={value}
              onChange={(e) => handleChange(key, e)}
              style={styles.input}
            />
          )
        )}
        <button type="submit" style={editingIndex !== null ? styles.buttonUpdate : styles.buttonAdd}>
          {editingIndex !== null ? 'Cập nhật' : 'Thêm'}
        </button>
      </form>

      <table style={styles.table}>
        <thead>
          <tr>
            {Object.keys(form).map((key) => (
              <th key={key}>{fieldLabels[key]}</th>
            ))}
            <th>Hành động</th>
          </tr>
        </thead>
        <tbody>
          {stores.map((store, index) => (
            <tr key={index}>
              {Object.values(store).map((val, i) => (
                <td key={i}>{val}</td>
              ))}
              <td>
                <button onClick={() => handleEdit(index)} style={styles.editBtn}>Sửa</button>
                <button onClick={() => handleDelete(index)} style={styles.deleteBtn}>Xóa</button>
              </td>
            </tr>
          ))}
          {stores.length === 0 && (
            <tr>
              <td colSpan={Object.keys(form).length + 1} style={{ textAlign: 'center', padding: '1rem' }}>
                Chưa có cửa hàng nào.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

const styles = {
  container: {
    padding: '2rem',
    maxWidth: '1100px',
    margin: '0 auto',
    background: '#f9f9f9',
    minHeight: '100vh',
  },
  title: {
    fontSize: '1.8rem',
    marginBottom: '1.5rem',
    textAlign: 'center',
    color: '#2c3e50',
  },
  form: {
    display: 'flex',
    flexWrap: 'wrap',
    gap: '1rem',
    marginBottom: '2rem',
    justifyContent: 'center',
  },
  input: {
    padding: '0.5rem',
    flex: '1 1 240px',
    borderRadius: '4px',
    border: '1px solid #ccc',
    fontSize: '1rem',
  },
  buttonAdd: {
    padding: '0.6rem 1.5rem',
    background: '#28a745',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
  },
  buttonUpdate: {
    padding: '0.6rem 1.5rem',
    background: '#ffc107',
    color: 'black',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    backgroundColor: 'white',
    boxShadow: '0 0 8px rgba(0,0,0,0.1)',
  },
  editBtn: {
    background: '#17a2b8',
    border: 'none',
    padding: '0.4rem 0.8rem',
    borderRadius: '4px',
    marginRight: '0.5rem',
    color: 'white',
    cursor: 'pointer',
  },
  deleteBtn: {
    background: '#dc3545',
    border: 'none',
    padding: '0.4rem 0.8rem',
    borderRadius: '4px',
    color: 'white',
    cursor: 'pointer',
  },
};

export default StoreManagement;
