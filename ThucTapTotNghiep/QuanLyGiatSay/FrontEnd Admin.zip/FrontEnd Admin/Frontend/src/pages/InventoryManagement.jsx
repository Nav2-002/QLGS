import React, { useState } from 'react';

const InventoryManagement = () => {
  const [items, setItems] = useState([]);
  const [form, setForm] = useState({
    itemId: '',
    itemName: '',
    quantity: '',
    status: '',
  });
  const [editingIndex, setEditingIndex] = useState(null);

  const handleChange = (field, e) => {
    let value = e.target.value;

    // Tự động cập nhật trạng thái khi số lượng thay đổi
    if (field === 'quantity') {
      const qty = parseInt(value, 10);
      value = isNaN(qty) ? '' : qty;
      form.status = qty > 0 ? 'Tồn' : 'Hết';
    }

    setForm({ ...form, [field]: value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.itemId || !form.itemName || form.quantity === '') return;

    if (editingIndex !== null) {
      const updated = [...items];
      updated[editingIndex] = form;
      setItems(updated);
      setEditingIndex(null);
    } else {
      setItems([...items, form]);
    }

    setForm({
      itemId: '',
      itemName: '',
      quantity: '',
      status: '',
    });
  };

  const handleEdit = (index) => {
    setForm(items[index]);
    setEditingIndex(index);
  };

  const handleDelete = (index) => {
    if (window.confirm('Bạn có chắc muốn xóa hàng hóa này không?')) {
      const updated = [...items];
      updated.splice(index, 1);
      setItems(updated);
    }
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.title}>Quản lý hàng hóa trong kho 📦</h2>

      <form onSubmit={handleSubmit} style={styles.form}>
        <input
          type="text"
          placeholder="ID hàng hóa"
          value={form.itemId}
          onChange={(e) => handleChange('itemId', e)}
          style={styles.input}
        />
        <input
          type="text"
          placeholder="Tên hàng hóa"
          value={form.itemName}
          onChange={(e) => handleChange('itemName', e)}
          style={styles.input}
        />
        <input
          type="number"
          placeholder="Số lượng tồn"
          value={form.quantity}
          onChange={(e) => handleChange('quantity', e)}
          style={styles.input}
        />
        <input
          type="text"
          placeholder="Trạng thái (tự động)"
          value={form.status}
          readOnly
          style={{ ...styles.input, backgroundColor: '#eee', cursor: 'not-allowed' }}
        />
        <button type="submit" style={styles.button}>
          {editingIndex !== null ? 'Cập nhật' : 'Thêm'}
        </button>
      </form>

      <table style={styles.table}>
        <thead>
          <tr>
            <th style={styles.th}>ID hàng hóa</th>
            <th style={styles.th}>Tên hàng hóa</th>
            <th style={styles.th}>Số lượng tồn</th>
            <th style={styles.th}>Trạng thái</th>
            <th style={styles.th}>Hành động</th>
          </tr>
        </thead>
        <tbody>
          {items.length > 0 ? (
            items.map((item, index) => (
              <tr key={index}>
                <td style={styles.td}>{item.itemId}</td>
                <td style={styles.td}>{item.itemName}</td>
                <td style={styles.td}>{item.quantity}</td>
                <td style={styles.td}>{item.status}</td>
                <td style={styles.td}>
                  <button onClick={() => handleEdit(index)} style={styles.editBtn}>Sửa</button>
                  <button onClick={() => handleDelete(index)} style={styles.deleteBtn}>Xóa</button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="5" style={{ textAlign: 'center', padding: '1rem' }}>
                Chưa có hàng hóa nào.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

const styles = {
  container: {
    padding: '2rem',
    maxWidth: '1000px',
    margin: '0 auto',
    background: '#f0f4f8',
    minHeight: '100vh',
  },
  title: {
    fontSize: '1.8rem',
    marginBottom: '1.5rem',
    textAlign: 'center',
    color: '#2c3e50',
  },
  form: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))',
    gap: '1rem',
    marginBottom: '2rem',
  },
  input: {
    padding: '0.6rem 0.8rem',
    borderRadius: '6px',
    border: '1px solid #ccc',
    fontSize: '1rem',
    width: '100%',
    boxSizing: 'border-box',
  },
  button: {
    padding: '0.6rem 1.2rem',
    background: '#007bff',
    color: 'white',
    border: 'none',
    borderRadius: '6px',
    fontSize: '1rem',
    cursor: 'pointer',
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    backgroundColor: 'white',
    boxShadow: '0 0 8px rgba(0,0,0,0.1)',
  },
  th: {
    background: '#f0f0f0',
    padding: '0.75rem',
    textAlign: 'center',
    fontWeight: '600',
  },
  td: {
    padding: '0.75rem',
    textAlign: 'center',
    borderTop: '1px solid #ddd',
  },
  editBtn: {
    background: '#ffc107',
    border: 'none',
    padding: '0.4rem 0.8rem',
    borderRadius: '4px',
    marginRight: '0.5rem',
    cursor: 'pointer',
  },
  deleteBtn: {
    background: '#dc3545',
    border: 'none',
    padding: '0.4rem 0.8rem',
    borderRadius: '4px',
    color: 'white',
    cursor: 'pointer',
  },
};

export default InventoryManagement;
