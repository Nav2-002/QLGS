import React, { useState } from 'react';

const PromotionManagement = () => {
  const [promotions, setPromotions] = useState([]);
  const [form, setForm] = useState({
    id: '',
    name: '',
    description: '',
    discount: '',
    startDate: '',
    endDate: '',
  });
  const [editingIndex, setEditingIndex] = useState(null);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.id || !form.name || !form.discount || !form.startDate || !form.endDate) return;

    const updated = [...promotions];
    if (editingIndex !== null) {
      updated[editingIndex] = form;
      setEditingIndex(null);
    } else {
      updated.push(form);
    }

    setPromotions(updated);
    setForm({ id: '', name: '', description: '', discount: '', startDate: '', endDate: '' });
  };

  const handleEdit = (index) => {
    setForm(promotions[index]);
    setEditingIndex(index);
  };

  const handleDelete = (index) => {
    if (window.confirm('Bạn có chắc muốn xóa chương trình khuyến mãi này không?')) {
      const updated = [...promotions];
      updated.splice(index, 1);
      setPromotions(updated);
    }
  };

  const getStatus = (startDate, endDate) => {
    const today = new Date();
    const start = new Date(startDate);
    const end = new Date(endDate);
    if (today < start) return 'Chưa bắt đầu';
    if (today >= start && today <= end) return 'Đang chạy';
    return 'Hết';
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.title}>🎁 Quản lý khuyến mãi</h2>

      <form onSubmit={handleSubmit} style={styles.form}>
        <div style={styles.grid}>
          <input
            type="text"
            name="id"
            placeholder="ID khuyến mãi"
            value={form.id}
            onChange={handleChange}
            style={styles.input}
          />
          <input
            type="text"
            name="name"
            placeholder="Tên khuyến mãi"
            value={form.name}
            onChange={handleChange}
            style={styles.input}
          />
          <input
            type="text"
            name="description"
            placeholder="Mô tả"
            value={form.description}
            onChange={handleChange}
            style={styles.input}
          />
          <input
            type="number"
            name="discount"
            placeholder="Giảm giá (%)"
            value={form.discount}
            onChange={handleChange}
            style={styles.input}
          />
          <input
            type="date"
            name="startDate"
            value={form.startDate}
            onChange={handleChange}
            style={styles.input}
          />
          <input
            type="date"
            name="endDate"
            value={form.endDate}
            onChange={handleChange}
            style={styles.input}
          />
        </div>

        <button type="submit" style={editingIndex !== null ? styles.buttonUpdate : styles.buttonAdd}>
          {editingIndex !== null ? 'Cập nhật' : 'Thêm'}
        </button>
      </form>

      <table style={styles.table}>
        <thead>
          <tr>
            <th style={styles.tableHeader}>ID</th>
            <th style={styles.tableHeader}>Tên</th>
            <th style={styles.tableHeader}>Mô tả</th>
            <th style={styles.tableHeader}>Giảm (%)</th>
            <th style={styles.tableHeader}>Bắt đầu</th>
            <th style={styles.tableHeader}>Kết thúc</th>
            <th style={styles.tableHeader}>Trạng thái</th>
            <th style={styles.tableHeader}>Hành động</th>
          </tr>
        </thead>
        <tbody>
          {promotions.length === 0 ? (
            <tr>
              <td colSpan="8" style={{ textAlign: 'center', padding: '1rem' }}>
                Chưa có chương trình nào.
              </td>
            </tr>
          ) : (
            promotions.map((promo, index) => (
              <tr key={index} style={styles.tableRow}>
                <td>{promo.id}</td>
                <td>{promo.name}</td>
                <td>{promo.description}</td>
                <td>{promo.discount}%</td>
                <td>{promo.startDate}</td>
                <td>{promo.endDate}</td>
                <td>{getStatus(promo.startDate, promo.endDate)}</td>
                <td>
                  <button onClick={() => handleEdit(index)} style={styles.editBtn}>Sửa</button>
                  <button onClick={() => handleDelete(index)} style={styles.deleteBtn}>Xóa</button>
                </td>
              </tr>
            ))
          )}
        </tbody>
      </table>
    </div>
  );
};

const styles = {
  container: {
    padding: '2rem',
    maxWidth: '1000px',
    margin: 'auto',
    background: '#f9f9f9',
    minHeight: '100vh',
  },
  title: {
    fontSize: '1.8rem',
    marginBottom: '1.5rem',
    textAlign: 'center',
    color: '#2c3e50',
  },
  form: {
    marginBottom: '2rem',
  },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(240px, 1fr))',
    gap: '1rem',
    marginBottom: '1rem',
  },
  input: {
    padding: '0.75rem',
    fontSize: '1rem',
    border: '1px solid #ccc',
    borderRadius: '6px',
    width: '100%',
  },
  buttonAdd: {
    padding: '0.6rem 1.5rem',
    background: '#28a745',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
  },
  buttonUpdate: {
    padding: '0.6rem 1.5rem',
    background: '#ffc107',
    color: 'black',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    backgroundColor: 'white',
    boxShadow: '0 0 8px rgba(0,0,0,0.1)',
    marginTop: '2rem',
  },
  tableHeader: {
    padding: '1rem',
    backgroundColor: '#f4f4f4',
    textAlign: 'left',
    fontWeight: 'bold',
  },
  tableRow: {
    borderBottom: '1px solid #ccc',
  },
  editBtn: {
    background: '#17a2b8',
    border: 'none',
    padding: '0.4rem 0.8rem',
    borderRadius: '4px',
    marginRight: '0.5rem',
    color: 'white',
    cursor: 'pointer',
  },
  deleteBtn: {
    background: '#dc3545',
    border: 'none',
    padding: '0.4rem 0.8rem',
    borderRadius: '4px',
    color: 'white',
    cursor: 'pointer',
  },
};

export default PromotionManagement;
