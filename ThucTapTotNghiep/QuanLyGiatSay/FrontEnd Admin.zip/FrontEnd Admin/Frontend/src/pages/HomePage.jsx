import React, { useEffect, useState } from 'react';
import axios from 'axios';
import { useNavigate } from 'react-router-dom';

const HomePage = () => {
  const [items, setItems] = useState([]); // State lưu dữ liệu từ BE
  const [loading, setLoading] = useState(true); // State để quản lý trạng thái loading
  const [error, setError] = useState(null); // State để quản lý lỗi
  const navigate = useNavigate(); // Sử dụng hook navigate để điều hướng

  const handleNavigate = (path) => {
    navigate(path);
  };

  // Lấy dữ liệu từ BE khi component được mount
  useEffect(() => {
    axios.get('http://localhost:5000/api/items') // Đường dẫn đến API của BE
      .then(response => {
        setItems(response.data); // Lưu dữ liệu từ BE vào state
        setLoading(false); // Đặt loading là false khi đã nhận được dữ liệu
      })
      .catch(error => {
        console.error('Error fetching data:', error);
        setError('Đã có lỗi khi lấy dữ liệu'); // Xử lý lỗi
        setLoading(false); // Dừng loading khi có lỗi
      });
  }, []); // Chạy một lần khi component mount

  if (loading) {
    return <div>Loading...</div>; // Hiển thị khi đang tải dữ liệu
  }

  if (error) {
    return <div>{error}</div>; // Hiển thị thông báo lỗi nếu có
  }

  return (
    <div style={styles.container}>
      <h2 style={styles.title}>📊 Trang Chủ Quản Lý</h2>
      <p style={styles.subtitle}>Chọn chức năng bạn muốn thao tác</p>
      <div style={styles.grid}>
        {buttons.map((btn) => (
          <div
            key={btn.path}
            style={styles.card}
            onClick={() => handleNavigate(btn.path)}
          >
            <span style={styles.icon}>{btn.icon}</span>
            <span>{btn.label}</span>
          </div>
        ))}
      </div>

      {/* Hiển thị danh sách items lấy từ BE */}
      <div>
        <h3>Danh sách Items:</h3>
        <ul>
          {items.map(item => (
            <li key={item.id}>
              <h4>{item.name}</h4>
              <p>{item.description}</p>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
};

const buttons = [
  { path: '/store', label: 'Quản lý cửa hàng', icon: '🏬' },
  { path: '/orders', label: 'Quản lý đơn hàng', icon: '📦' },
  { path: '/customers', label: 'Quản lý khách hàng', icon: '👥' },
  { path: '/services', label: 'Quản lý dịch vụ', icon: '🛠️' },
  { path: '/employees', label: 'Quản lý nhân viên', icon: '🧑‍💼' },
  { path: '/inventory', label: 'Quản lý kho', icon: '📦📦' },
  { path: '/promotions', label: 'Quản lý khuyến mãi', icon: '💰' },
];

const styles = {
  container: {
    padding: '3rem 2rem',
    background: 'linear-gradient(to right, #f8fbff, #eef5ff)',
    minHeight: '100vh',
    fontFamily: '"Segoe UI", sans-serif',
    textAlign: 'center',
  },
  title: {
    fontSize: '2rem',
    color: '#333',
    marginBottom: '0.5rem',
  },
  subtitle: {
    fontSize: '1rem',
    color: '#666',
    marginBottom: '2rem',
  },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
    gap: '1.5rem',
    padding: '0 1rem',
  },
  card: {
    padding: '1.5rem',
    background: '#ffffff',
    borderRadius: '12px',
    boxShadow: '0 4px 8px rgba(0,0,0,0.05)',
    cursor: 'pointer',
    transition: 'all 0.3s ease',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    fontSize: '1rem',
    color: '#333',
  },
  icon: {
    fontSize: '2rem',
    marginBottom: '0.5rem',
  },
};

export default HomePage;
