import React, { useState } from 'react';

const RegisterForm = () => {
  const [email, setEmail] = useState('');
  const [name, setName] = useState('');
  const [password, setPassword] = useState('');
  const [confirmPassword, setConfirmPassword] = useState('');
  const [address, setAddress] = useState('');
const [dob, setDob] = useState('');
const [phone, setPhone] = useState('');
const [gender, setGender] = useState('');
const [successMessage, setSuccessMessage] = useState('');



  const handleRegister = (e) => {
    e.preventDefault();
    if (password !== confirmPassword) {
      alert('Mật khẩu không khớp!');
      return;
    }

    console.log('Đăng ký:', {
  name,
  email,
  password,
  phone,

});
const newUser = {
  name,
  email,
  password,
  address,
  dob,
  phone,
  gender,
};

// Lưu vào localStorage (tạm thời)
localStorage.setItem('user', JSON.stringify(newUser));

// Hiện thông báo
setSuccessMessage('Đăng ký thành công!');

// Reset form (nếu muốn)
setName('');
setEmail('');
setPassword('');
setConfirmPassword('');
setAddress('');
setDob('');
setPhone('');
setGender('');

    // Gửi dữ liệu lên server tại đây
  };

  return (
    <div style={styles.container}>
        {successMessage && (
  <div style={styles.successMessage}>
    {successMessage}
  </div>
)}

      <form onSubmit={handleRegister} style={styles.form}>
        <h2 style={{ fontSize: '1.25rem', marginBottom: '1rem', textAlign: 'center' }}>
          ĐĂNG KÝ TÀI KHOẢN
        </h2>
        <input
          type="text"
          placeholder="Họ tên"
          value={name}
          onChange={(e) => setName(e.target.value)}
          required
          style={styles.input}
        />
        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          style={styles.input}
        />
        
        <input
            type="tel"
            placeholder="Số điện thoại"
            value={phone}
            onChange={(e) => setPhone(e.target.value)}
            required
            style={styles.input}
        />
       

        <input
          type="password"
          placeholder="Mật khẩu"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          style={styles.input}
        />
        <input
          type="password"
          placeholder="Nhập lại mật khẩu"
          value={confirmPassword}
          onChange={(e) => setConfirmPassword(e.target.value)}
          required
          style={styles.input}
        />
        <button type="submit" style={styles.button}>Đăng ký</button>
      </form>
    </div>
  );
};

const styles = {
  container: {
    height: '100vh',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    background: '#f0f0f0',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    padding: '2rem',
    borderRadius: '8px',
    background: 'white',
    boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
    width: '400px', // tăng chiều rộng form
  },
  
  input: {
    margin: '0.5rem 0',
    padding: '0.875rem', // tăng padding
    fontSize: '1.05rem', // tăng cỡ chữ
    border: '1px solid #ccc',
    borderRadius: '4px',
  },
  
  button: {
    marginTop: '1rem',
    padding: '0.875rem',
    fontSize: '1.05rem', // tăng cỡ chữ
    background: '#28a745',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
  },
  successMessage: {
    color: 'green',
    textAlign: 'center',
    marginBottom: '1rem',
    fontWeight: 'bold',
  }
  
};

export default RegisterForm;
