// src/components/BackgroundManagement.js
import React, { useState } from 'react';

const BackgroundManagement = () => {
  const [backgroundColor, setBackgroundColor] = useState('#f0f4f8');  // Màu nền mặc định

  // Hàm xử lý thay đổi màu nền
  const handleChangeBackground = (e) => {
    setBackgroundColor(e.target.value);  // Cập nhật màu nền khi người dùng thay đổi
  };

  return (
    <div style={{ padding: '2rem', background: backgroundColor, minHeight: '100vh' }}>
      <h2 style={styles.title}>Quản lý Background</h2>
      
      <div style={styles.container}>
        <label style={styles.label}>Chọn màu nền:</label>
        <input
          type="color"
          value={backgroundColor}
          onChange={handleChangeBackground}
          style={styles.colorPicker}
        />
      </div>

      <div style={styles.info}>
        <p style={styles.description}>Chọn màu sắc cho nền của trang web. Bạn có thể thay đổi nền bất kỳ lúc nào!</p>
      </div>
    </div>
  );
};

// Các style cho giao diện
const styles = {
  title: {
    fontSize: '1.8rem',
    color: '#333',
    marginBottom: '1rem',
    textAlign: 'center',
    fontWeight: 'bold',
  },
  container: {
    display: 'flex',
    flexDirection: 'column',
    gap: '1rem',
    alignItems: 'center',
  },
  label: {
    fontSize: '1.2rem',
    color: '#555',
  },
  colorPicker: {
    padding: '0.5rem',
    width: '60px',
    height: '40px',
    border: 'none',
    borderRadius: '6px',
    cursor: 'pointer',
  },
  info: {
    marginTop: '2rem',
    textAlign: 'center',
  },
  description: {
    fontSize: '1rem',
    color: '#777',
  },
};

export default BackgroundManagement;
