import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';

const LoginForm = () => {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [role, setRole] = useState('');
  const [errorMessage, setErrorMessage] = useState('');

  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
  
    if (!email || !password) {
      alert('Vui lòng nhập đầy đủ email và mật khẩu!');
      return;
    }
  
    if (!role) {
      alert('Vui lòng chọn vai trò: Nhân viên hoặc Quản lý!');
      return;
    }
  
    if (role === 'Quản lý') {
      if (email === 'huynh@gmail.com' && password === '123456') {
        navigate('/home');
      } else {
        alert('Tài khoản quản lý không đúng!');
      }
    } else {
      // Nhân viên đăng nhập linh hoạt
      navigate('/home');
    }
  };
  

  return (
    <div style={styles.container}>
      <form onSubmit={handleLogin} style={styles.form}>
        <h2 style={{ fontSize: '1.25rem', marginBottom: '1rem', textAlign: 'center' }}>
          TRANG ĐĂNG NHẬP KHÁCH HÀNG
        </h2>

        {errorMessage && (
          <div style={{ color: 'red', marginBottom: '1rem', textAlign: 'center' }}>
            {errorMessage}
          </div>
        )}

        <input
          type="email"
          placeholder="Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          required
          style={styles.input}
        />
        <input
          type="password"
          placeholder="Mật khẩu"
          value={password}
          onChange={(e) => setPassword(e.target.value)}
          required
          style={styles.input}
        />

        {/* Vai trò */}
        <div style={{ margin: '0.5rem 0' }}>
          <label style={{ marginRight: '0.5rem' }}>Vai trò:</label>
          <label>
            <input
              type="radio"
              name="role"
              value="Nhân viên"
              checked={role === 'Nhân viên'}
              onChange={(e) => setRole(e.target.value)}
            /> Nhân viên
          </label>
          <label style={{ marginLeft: '1rem' }}>
            <input
              type="radio"
              name="role"
              value="Quản lý"
              checked={role === 'Quản lý'}
              onChange={(e) => setRole(e.target.value)}
            /> Quản lý
          </label>
        </div>

        <button type="submit" style={styles.button}>Đăng nhập</button>

        <div style={{ marginTop: '1rem', textAlign: 'center' }}>
          <Link to="/forgot-password" style={{ marginRight: '1rem' }}>Quên mật khẩu?</Link>
          <Link to="/register">Đăng ký</Link>
        </div>
      </form>
    </div>
  );
};

const styles = {
  container: {
    height: '100vh',
    display: 'flex',
    justifyContent: 'center',
    alignItems: 'center',
    background: '#f0f0f0',
  },
  form: {
    display: 'flex',
    flexDirection: 'column',
    padding: '2rem',
    borderRadius: '8px',
    background: 'white',
    boxShadow: '0 2px 8px rgba(0,0,0,0.1)',
    width: '400px',
  },
  input: {
    margin: '0.5rem 0',
    padding: '0.75rem',
    fontSize: '1rem',
    border: '1px solid #ccc',
    borderRadius: '4px',
  },
  button: {
    marginTop: '1rem',
    padding: '0.75rem',
    fontSize: '1rem',
    background: '#007bff',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
  },
};

export default LoginForm;
