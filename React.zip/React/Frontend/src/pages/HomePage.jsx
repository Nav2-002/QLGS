import React from 'react';
import { useNavigate } from 'react-router-dom';

const HomePage = () => {
  const navigate = useNavigate();

  const handleNavigate = (path) => {
    navigate(path);
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.title}>📊 Trang Chủ Quản Lý</h2>
      <p style={styles.subtitle}>Chọn chức năng bạn muốn thao tác</p>
      <div style={styles.grid}>
        {buttons.map((btn) => (
          <div
            key={btn.path}
            style={styles.card}
            onClick={() => handleNavigate(btn.path)}
          >
            <span style={styles.icon}>{btn.icon}</span>
            <span>{btn.label}</span>
          </div>
        ))}
      </div>
    </div>
  );
};

const buttons = [
  { path: '/store', label: 'Quản lý cửa hàng', icon: '🏬' },
  { path: '/orders', label: 'Quản lý đơn hàng', icon: '📦' },
  { path: '/customers', label: 'Quản lý khách hàng', icon: '👥' },
  { path: '/services', label: 'Quản lý dịch vụ', icon: '🛠️' },
  { path: '/employees', label: 'Quản lý nhân viên', icon: '🧑‍💼' },
  { path: '/inventory', label: 'Quản lý kho', icon: '📦📦' },
];

const styles = {
  container: {
    padding: '3rem 2rem',
    background: 'linear-gradient(to right, #f8fbff, #eef5ff)',
    minHeight: '100vh',
    fontFamily: '"Segoe UI", sans-serif',
    textAlign: 'center',
  },
  title: {
    fontSize: '2rem',
    color: '#333',
    marginBottom: '0.5rem',
  },
  subtitle: {
    fontSize: '1rem',
    color: '#666',
    marginBottom: '2rem',
  },
  grid: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fit, minmax(180px, 1fr))',
    gap: '1.5rem',
    padding: '0 1rem',
  },
  card: {
    padding: '1.5rem',
    background: '#ffffff',
    borderRadius: '12px',
    boxShadow: '0 4px 8px rgba(0,0,0,0.05)',
    cursor: 'pointer',
    transition: 'all 0.3s ease',
    display: 'flex',
    flexDirection: 'column',
    alignItems: 'center',
    fontSize: '1rem',
    color: '#333',
  },
  icon: {
    fontSize: '2rem',
    marginBottom: '0.5rem',
  },
};

export default HomePage;
