import React, { useState } from 'react';

const OrderManagement = () => {
  const [orders, setOrders] = useState([]);
  const [form, setForm] = useState({
    orderId: '',
    storeId: '',
    customerId: '',
    employeeId: '',
    receiveDate: '',
    deliveryDate: '',
    receiveAddress: '',
    deliveryAddress: '',
    totalAmount: '',
    discountAmount: '',
    collectedAmount: '',
    status: '',
  });
  const [editingIndex, setEditingIndex] = useState(null);

  const handleChange = (field, e) => {
    setForm({ ...form, [field]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!form.orderId || !form.customerId) return;

    const updatedOrders = [...orders];
    if (editingIndex !== null) {
      updatedOrders[editingIndex] = form;
      setEditingIndex(null);
    } else {
      updatedOrders.push(form);
    }

    setOrders(updatedOrders);
    setForm({
      orderId: '',
      storeId: '',
      customerId: '',
      employeeId: '',
      receiveDate: '',
      deliveryDate: '',
      receiveAddress: '',
      deliveryAddress: '',
      totalAmount: '',
      discountAmount: '',
      collectedAmount: '',
      status: '',
    });
  };

  const handleEdit = (index) => {
    setForm(orders[index]);
    setEditingIndex(index);
  };

  const handleDelete = (index) => {
    if (window.confirm('Bạn có chắc muốn xóa đơn hàng này không?')) {
      const updated = [...orders];
      updated.splice(index, 1);
      setOrders(updated);
    }
  };

  const fieldLabels = {
    orderId: 'ID đơn',
    storeId: 'ID cửa hàng',
    customerId: 'ID khách',
    employeeId: 'ID nhân viên',
    receiveDate: 'Ngày nhận',
    deliveryDate: 'Ngày trả',
    receiveAddress: 'Địa chỉ nhận',
    deliveryAddress: 'Địa chỉ giao',
    totalAmount: 'Tổng tiền',
    discountAmount: 'Tiền khuyến mãi',
    collectedAmount: 'Tiền thu',
    status: 'Trạng thái',
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.title}>Quản lý đơn hàng 📦</h2>

      <form onSubmit={handleSubmit} style={styles.form}>
        {Object.entries(form).map(([key, value]) =>
          key === 'status' ? (
            <select
              key={key}
              value={value}
              onChange={(e) => handleChange(key, e)}
              style={styles.input}
            >
              <option value="">-- Chọn trạng thái --</option>
              <option value="ĐÃ NHẬN">Đã nhận</option>
              <option value="Đang giặt">Đang giặt</option>
              <option value="Đang sấy">Đang sấy</option>
              <option value="Đã xong">Đã xong</option>
            </select>
          ) : (
            <input
              key={key}
              type={
                key.includes('Date') ? 'date' : 
                key.includes('Amount') ? 'number' : 
                'text'
              }
              placeholder={fieldLabels[key]}
              value={value}
              onChange={(e) => handleChange(key, e)}
              style={styles.input}
            />
          )
        )}
        <button type="submit" style={editingIndex !== null ? styles.buttonUpdate : styles.buttonAdd}>
          {editingIndex !== null ? 'Cập nhật' : 'Thêm'}
        </button>
      </form>

      <table style={styles.table}>
        <thead>
          <tr>
            {Object.keys(form).map((key) => (
              <th key={key}>{fieldLabels[key]}</th>
            ))}
            <th>Hành động</th>
          </tr>
        </thead>
        <tbody>
          {orders.map((order, index) => (
            <tr key={index}>
              {Object.values(order).map((val, i) => (
                <td key={i}>{val}</td>
              ))}
              <td>
                <button onClick={() => handleEdit(index)} style={styles.editBtn}>Sửa</button>
                <button onClick={() => handleDelete(index)} style={styles.deleteBtn}>Xóa</button>
              </td>
            </tr>
          ))}
          {orders.length === 0 && (
            <tr>
              <td colSpan={Object.keys(form).length + 1} style={{ textAlign: 'center', padding: '1rem' }}>
                Chưa có đơn hàng nào.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

const styles = {
  container: {
    padding: '2rem',
    maxWidth: '1200px',
    margin: '0 auto',
    background: '#f9f9f9',
    minHeight: '100vh',
  },
  title: {
    fontSize: '1.8rem',
    marginBottom: '1.5rem',
    textAlign: 'center',
    color: '#2c3e50',
  },
  form: {
    display: 'flex',
    flexWrap: 'wrap',
    gap: '1rem',
    marginBottom: '2rem',
    justifyContent: 'center',
  },
  input: {
    padding: '0.5rem',
    flex: '1 1 240px',
    borderRadius: '4px',
    border: '1px solid #ccc',
    fontSize: '1rem',
  },
  buttonAdd: {
    padding: '0.6rem 1.5rem',
    background: '#28a745',
    color: 'white',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
  },
  buttonUpdate: {
    padding: '0.6rem 1.5rem',
    background: '#ffc107',
    color: 'black',
    border: 'none',
    borderRadius: '4px',
    cursor: 'pointer',
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    backgroundColor: 'white',
    boxShadow: '0 0 8px rgba(0,0,0,0.1)',
  },
  editBtn: {
    background: '#17a2b8',
    border: 'none',
    padding: '0.4rem 0.8rem',
    borderRadius: '4px',
    marginRight: '0.5rem',
    color: 'white',
    cursor: 'pointer',
  },
  deleteBtn: {
    background: '#dc3545',
    border: 'none',
    padding: '0.4rem 0.8rem',
    borderRadius: '4px',
    color: 'white',
    cursor: 'pointer',
  },
};

export default OrderManagement;
