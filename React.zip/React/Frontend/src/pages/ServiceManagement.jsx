import React, { useState } from 'react';

const ServiceManagement = () => {
  const [services, setServices] = useState([]);
  const [form, setForm] = useState({ name: '', price: '', description: '' });
  const [editingIndex, setEditingIndex] = useState(null);

  const handleChange = (e) => {
    setForm({ ...form, [e.target.name]: e.target.value });
  };

  const handleAdd = () => {
    if (!form.name || !form.price) return;
    setServices([...services, form]);
    setForm({ name: '', price: '', description: '' });
  };

  const handleEdit = (index) => {
    setForm(services[index]);
    setEditingIndex(index);
  };

  const handleUpdate = () => {
    const updated = [...services];
    updated[editingIndex] = form;
    setServices(updated);
    setForm({ name: '', price: '', description: '' });
    setEditingIndex(null);
  };

  const handleDelete = (index) => {
    const updated = [...services];
    updated.splice(index, 1);
    setServices(updated);
  };

  return (
    <div style={styles.container}>
      <h2 style={styles.title}>💼 Quản Lý Dịch Vụ</h2>

      <form style={styles.form} onSubmit={(e) => e.preventDefault()}>
        <input
          type="text"
          name="name"
          placeholder="Tên dịch vụ"
          value={form.name}
          onChange={handleChange}
          style={styles.input}
        />
        <input
          type="number"
          name="price"
          placeholder="Giá (VNĐ)"
          value={form.price}
          onChange={handleChange}
          style={styles.input}
        />
        <input
          type="text"
          name="description"
          placeholder="Mô tả"
          value={form.description}
          onChange={handleChange}
          style={styles.input}
        />
        {editingIndex !== null ? (
          <button type="button" onClick={handleUpdate} style={styles.buttonUpdate}>✔️ Cập nhật</button>
        ) : (
          <button type="button" onClick={handleAdd} style={styles.buttonAdd}>➕ Thêm</button>
        )}
      </form>

      <table style={styles.table}>
        <thead>
          <tr>
            <th style={styles.th}>Tên dịch vụ</th>
            <th style={styles.th}>Giá</th>
            <th style={styles.th}>Mô tả</th>
            <th style={styles.th}>Hành động</th>
          </tr>
        </thead>
        <tbody>
          {services.length > 0 ? (
            services.map((service, index) => (
              <tr key={index}>
                <td style={styles.td}>{service.name}</td>
                <td style={styles.td}>{Number(service.price).toLocaleString()} VNĐ</td>
                <td style={styles.td}>{service.description || 'Không có mô tả'}</td>
                <td style={styles.td}>
                  <button onClick={() => handleEdit(index)} style={styles.editBtn}>✏️</button>
                  <button onClick={() => handleDelete(index)} style={styles.deleteBtn}>🗑️</button>
                </td>
              </tr>
            ))
          ) : (
            <tr>
              <td colSpan="4" style={{ textAlign: 'center', padding: '1rem', fontStyle: 'italic' }}>
                Chưa có dịch vụ nào được thêm.
              </td>
            </tr>
          )}
        </tbody>
      </table>
    </div>
  );
};

const styles = {
  container: {
    padding: '2rem',
    maxWidth: '900px',
    margin: '0 auto',
    background: '#f8f9fa',
    minHeight: '100vh',
  },
  title: {
    fontSize: '1.8rem',
    marginBottom: '1.5rem',
    textAlign: 'center',
    color: '#2c3e50',
  },
  form: {
    display: 'grid',
    gridTemplateColumns: 'repeat(auto-fill, minmax(240px, 1fr))',
    gap: '1rem',
    marginBottom: '2rem',
  },
  input: {
    padding: '0.7rem',
    borderRadius: '6px',
    border: '1px solid #ccc',
    fontSize: '1rem',
    width: '100%',
    boxSizing: 'border-box',
  },
  buttonAdd: {
    gridColumn: 'span 1',
    padding: '0.7rem',
    backgroundColor: '#28a745',
    color: '#fff',
    border: 'none',
    borderRadius: '6px',
    fontWeight: 'bold',
    cursor: 'pointer',
  },
  buttonUpdate: {
    gridColumn: 'span 1',
    padding: '0.7rem',
    backgroundColor: '#ffc107',
    color: '#000',
    border: 'none',
    borderRadius: '6px',
    fontWeight: 'bold',
    cursor: 'pointer',
  },
  table: {
    width: '100%',
    borderCollapse: 'collapse',
    backgroundColor: 'white',
    boxShadow: '0 0 8px rgba(0,0,0,0.1)',
  },
  th: {
    background: '#f0f0f0',
    padding: '0.75rem',
    textAlign: 'center',
    fontWeight: '600',
  },
  td: {
    padding: '0.75rem',
    textAlign: 'center',
    borderTop: '1px solid #ddd',
  },
  editBtn: {
    background: '#007bff',
    border: 'none',
    padding: '0.4rem 0.8rem',
    borderRadius: '4px',
    marginRight: '0.5rem',
    color: 'white',
    cursor: 'pointer',
  },
  deleteBtn: {
    background: '#dc3545',
    border: 'none',
    padding: '0.4rem 0.8rem',
    borderRadius: '4px',
    color: 'white',
    cursor: 'pointer',
  },
};

export default ServiceManagement;
