import React from 'react';
import { Routes, Route } from 'react-router-dom';
import LoginForm from './components/LoginForm';
import ForgotPassword from './components/ForgotPassword';
import RegisterForm from './components/RegisterForm'; // <- thêm dòng này
import HomePage from './pages/HomePage';
import StoreManagement from './pages/StoreManagement'; // 👈 cần có dòng này
import OrderManagement from './pages/OrderManagement'; // <- THÊM dòng này
import CustomerManagement from './pages/CustomerManagement';
import ServiceManagement from './pages/ServiceManagement';
import EmployeeManagement from './pages/EmployeeManagement';
import InventoryManagement from './pages/InventoryManagement';



function App() {
  return (
    <Routes>
      <Route path="/" element={<LoginForm />} />
      <Route path="/forgot-password" element={<ForgotPassword />} />
      <Route path="/register" element={<RegisterForm />} /> {/* <- thêm dòng này */}
      <Route path="/home" element={<HomePage />} />
      <Route path="/store" element={<StoreManagement />} />
      <Route path="/orders" element={<OrderManagement />} />
      <Route path="/customers" element={<CustomerManagement />} />
      <Route path="/services" element={<ServiceManagement />} />
      <Route path="/employees" element={<EmployeeManagement />} />
      <Route path="/inventory" element={<InventoryManagement />} />

    </Routes>
    
  );
}

export default App;
